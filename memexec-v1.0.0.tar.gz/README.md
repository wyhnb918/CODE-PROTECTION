# memexec - 从内存直接执行 ELF

**memexec** 是一个轻量级 ELF 加载器，可直接从内存执行动态可执行程序（ET_DYN，包括 PIE 和共享库）。主程序完全在内存中运行，不产生临时文件（共享库依赖可能从磁盘加载）。

### 💻 开发环境

本项目完全在 Android 上的 Termux 内开发和测试。所有编译、链接和执行均在设备本地完成。

- **平台：** Android（通过 Termux）
- **编译器：** GCC（Termux 内）
- **C 库：** Bionic（Android 的 C 库）

### ✨ 特性

- **纯内存执行** — 主 ELF 二进制文件直接从缓冲区加载并运行。
- **动态链接支持** — 自动解析 `DT_NEEDED` 共享库依赖（由 `dlopen` 从磁盘加载）。
- **递归依赖加载** — 正确处理库依赖链，支持 `RUNPATH`/`LD_LIBRARY_PATH` 路径解析。
- **完整重定位处理** — 支持 `R_AARCH64_RELATIVE`、`GLOB_DAT`、`ABS64`、`COPY`、`IRELATIVE`、`JUMP_SLOT` 及基本 TLS 重定位。
- **兼容 C++** — 正确处理全局对象构造/析构（`init_array`、`fini_array`、`__cxa_finalize`）。
- **原生 TLS 支持（实验性）** — 检测 `PT_TLS` 段，通过 `clone()` 创建独立线程并提供专属 TLS 块。严重依赖 `pthread` 功能的程序可能冲突，详见注意事项。
- **简洁 API** — 一个函数调用：`memexec(data, size, argc, argv)`。
- **最小依赖** — 仅需标准 C 库和 `libdl`，无其他外部依赖。
- **默认零输出** — 调试日志通过 `-DDEBUG` 编译开关控制。

### 🚀 快速开始

c:
#include "memexec.h"

void *elf_data = ...;   // 例如，在内存中解密后的数据
size_t elf_size = ...;

char *argv[] = {"./prog", "--arg1", "--arg2", NULL};
int ret = memexec(elf_data, elf_size, 3, argv);
// ret 即 main() 的返回值


编译（无调试输出）：

gcc -o loader loader.c memexec.c -ldl

开启调试日志：

gcc -DDEBUG -o loader loader.c memexec.c -ldl

一个带错误检查的 loader.c 示例，读取 ELF 文件并从内存执行：

#include "memexec.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <elf_file> [args...]\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    struct stat st;
    fstat(fd, &st);
    void *data = malloc(st.st_size);
    ssize_t n = read(fd, data, st.st_size);
    close(fd);
    if (n != st.st_size) {
        fprintf(stderr, "Failed to read ELF file\n");
        free(data);
        return 1;
    }

    int ret = memexec(data, st.st_size, argc - 1, argv + 1);
    printf("memexec returned: %d\n", ret);
    free(data);
    return 0;
}


📦 用于 APK

memexec 可编译为原生共享库（.so），通过 JNI 集成到 Android APK 项目中。适用于加密或加壳载荷的内存执行场景，主程序不落盘。

📋 要求与限制

架构支持： 仅支持 AArch64（ARM64）。x86_64、ARM32、x86 均不支持。

ELF 类型： 仅支持动态可执行文件（ET_DYN，即 -fPIE -pie 编译）。静态可执行文件不受支持。

目标程序要求：

· 必须以位置无关方式编译（-fPIE -pie）。
· 应使用与加载器相同或兼容的 libc（例如，同 Android 版本的 Bionic）。
· 不建议依赖 setjmp/longjmp 或复杂的信号处理（未经测试）。

已知注意事项：

· TLS 支持 通过 clone() 创建新线程并设置自定义 TLS 块来实现。严重依赖 pthread_self()、pthread_create() 等高级 pthread 特性的程序可能出现异常或崩溃。
· 信号处理 和 setjmp/longjmp 未进行显式测试，可能导致未定义行为。
· 安全性： 加载器仅进行最小限度的 ELF 验证。加载来自不可信源的 ELF 数据极其危险，可能导致任意代码执行。
· 内存保护： 已加载的段遵循 W^X 原则（代码段 RX，数据段 RW）。但加载器本身在重定位期间以 RWX 权限运行。

性能： 重定位处理时间复杂度为 O(n)（n 为重定位数量）。内存开销为加载的 ELF 大小加上少量固定结构及 TLS（如使用）的占用。

⚠️ 法律声明

本软件仅可用于合法目的，包括软件保护、安全研究和 ELF 加载机制的教育学习。作者不承担任何滥用或损害的责任。使用本软件即表示您同意遵守所有适用法律。

🐛 问题反馈

在 GitHub 提交 Issue。
欢迎反馈

📁 项目文件

· memexec.h — 公开 API 头文件
· memexec.c — 核心 ELF 加载器实现
· loader.c — 示例加载器（文件 → 内存 → 执行）
· README.md — 本文档

📄 许可证

MIT

-------------------------------------------------------------------------------

本项目在 AI 辅助下开发，所有 AI 生成内容均经过人工审查和测试。
