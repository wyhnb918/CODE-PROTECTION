#include "memexec.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <elf_file> [args...]\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    struct stat st;
    fstat(fd, &st);
    void *data = malloc(st.st_size);
    read(fd, data, st.st_size);
    close(fd);

    int ret = memexec(data, st.st_size, argc - 1, argv + 1);
    printf("memexec returned: %d\n", ret);
    free(data);
    return 0;
}
