#define _GNU_SOURCE
#include "memexec.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/auxv.h>
#include <fcntl.h>
#include <unistd.h>
#include <sched.h>
#include <elf.h>
#include <dlfcn.h>
#include <errno.h>

#ifdef DEBUG
#define LOG(fmt, ...) fprintf(stderr, "[memexec] " fmt "\n", ##__VA_ARGS__)
#else
#define LOG(fmt, ...) ((void)0)
#endif

#ifndef CLONE_SETTLS
#define CLONE_SETTLS 0x00080000
#endif
#ifndef FUTEX_WAIT
#define FUTEX_WAIT 0
#endif

#define TLS_TCB_SIZE 0x700
#define TLS_DTV_ENTRIES 64

typedef struct {
    void *dtv[TLS_DTV_ENTRIES];
    char padding[TLS_TCB_SIZE];
} tcb_t;

typedef struct {
    Elf64_Addr vaddr;
    size_t memsz;
    int writeable;
} seg_t;

static void *find_sym(const char *name);
static void *smart_dlopen(const char *name, const char *runpath);

static int tls_module_id = 0;
static size_t tls_init_size = 0, tls_total_size = 0;
static void *tls_template = NULL;
static int has_tls = 0;

static void parse_tls(const void *elf_data, size_t elf_size, void *base) {
    const Elf64_Ehdr *ehdr = (const Elf64_Ehdr*)elf_data;
    const Elf64_Phdr *ph = (const Elf64_Phdr*)((const char*)elf_data + ehdr->e_phoff);
    for (int i = 0; i < ehdr->e_phnum; i++) {
        if (ph[i].p_type == PT_TLS) {
            tls_init_size = ph[i].p_filesz;
            tls_total_size = ph[i].p_memsz;
            tls_template = (char*)base + ph[i].p_vaddr;
            has_tls = 1;
        }
    }
}

static void *allocate_tls() {
    if (!has_tls) return NULL;
    size_t size = tls_total_size + TLS_TCB_SIZE;
    void *block = mmap(NULL, size, PROT_READ|PROT_WRITE,
                       MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (block == MAP_FAILED) return NULL;
    tcb_t *tcb = (tcb_t*)block;
    memset(tcb, 0, sizeof(tcb_t));
    void *prog_tls = (char*)block + TLS_TCB_SIZE;
    if (tls_template) {
        memcpy(prog_tls, tls_template, tls_init_size);
        if (tls_total_size > tls_init_size)
            memset((char*)prog_tls + tls_init_size, 0, tls_total_size - tls_init_size);
    }
    tcb->dtv[1] = prog_tls;
    return block;
}

static void set_tls(void *tls_base) {
    void (*__set_tls)(void*) = find_sym("__set_tls");
    if (__set_tls) __set_tls(tls_base);
    else syscall(__NR_prctl, 0x4003, tls_base, 0, 0);
}

static void *find_sym(const char *name) {
    dlerror();
    void *addr = dlsym(RTLD_DEFAULT, name);
    if (addr) return addr;
    char buf[256];
    strncpy(buf, name, 255); buf[255] = '\0';
    char *p = strchr(buf, '@');
    if (p) *p = '\0';
    addr = dlsym(RTLD_DEFAULT, buf);
    if (addr) return addr;
    return NULL;
}

static int parse_elf_needed(const char *path, char out_needed[][128], int max,
                            char *out_runpath, size_t rp_sz) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return 0;
    struct stat st;
    if (fstat(fd, &st) || st.st_size < (off_t)sizeof(Elf64_Ehdr)) { close(fd); return 0; }
    void *map = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (map == MAP_FAILED) return 0;
    const Elf64_Ehdr *ehdr = (const Elf64_Ehdr*)map;
    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG)) { munmap(map, st.st_size); return 0; }
    const Elf64_Phdr *ph = (const Elf64_Phdr*)((const char*)map + ehdr->e_phoff);
    const Elf64_Phdr *ph_dyn = NULL;
    for (int i = 0; i < ehdr->e_phnum; i++)
        if (ph[i].p_type == PT_DYNAMIC) { ph_dyn = &ph[i]; break; }
    if (!ph_dyn) { munmap(map, st.st_size); return 0; }
    const Elf64_Dyn *dyn = (const Elf64_Dyn*)((const char*)map + ph_dyn->p_vaddr);
    const char *strtab = NULL;
    Elf64_Xword runpath_off = 0;
    int has_runpath = 0, needed_off[50], needed_n = 0;
    for (int i = 0; dyn[i].d_tag != DT_NULL; i++) {
        switch (dyn[i].d_tag) {
            case DT_STRTAB: strtab = (const char*)map + dyn[i].d_un.d_ptr; break;
            case DT_RUNPATH: case DT_RPATH:
                runpath_off = dyn[i].d_un.d_val; has_runpath = 1; break;
            case DT_NEEDED:
                if (needed_n < 50) needed_off[needed_n++] = dyn[i].d_un.d_val; break;
        }
    }
    if (strtab && needed_n > 0) {
        int count = 0;
        for (int i = 0; i < needed_n && count < max; i++) {
            strncpy(out_needed[count], strtab + needed_off[i], 127);
            out_needed[count][127] = '\0'; count++;
        }
        if (has_runpath && out_runpath) {
            strncpy(out_runpath, strtab + runpath_off, rp_sz - 1);
            out_runpath[rp_sz - 1] = '\0';
        } else if (out_runpath) out_runpath[0] = '\0';
        munmap(map, st.st_size); return count;
    }
    munmap(map, st.st_size); return 0;
}

static void *dlopen_with_deps(const char *path, const char *runpath_hint) {
    char needed[20][128], dep_runpath[1024];
    int n = parse_elf_needed(path, needed, 20, dep_runpath, sizeof(dep_runpath));
    for (int i = 0; i < n; i++) {
        const char *rp = dep_runpath[0] ? dep_runpath : runpath_hint;
        if (!smart_dlopen(needed[i], rp)) return NULL;
    }
    void *h = dlopen(path, RTLD_NOW|RTLD_GLOBAL);
    return h;
}

static void *smart_dlopen(const char *name, const char *runpath) {
    void *h = dlopen(name, RTLD_NOLOAD|RTLD_NOW|RTLD_GLOBAL);
    if (h) return h;
    const char *attempts[100]; int ntry = 0; char tmp[1024];
    attempts[ntry++] = name;
    if (name[0] != '/') { snprintf(tmp, sizeof(tmp), "./%s", name); attempts[ntry++] = strdup(tmp); }
    const char *ldpath = getenv("LD_LIBRARY_PATH");
    if (ldpath) {
        char *path = strdup(ldpath);
        if (path) {
            char *saveptr, *dir = strtok_r(path, ":", &saveptr);
            while (dir && ntry < 99) {
                snprintf(tmp, sizeof(tmp), "%s/%s", dir, name);
                attempts[ntry++] = strdup(tmp); dir = strtok_r(NULL, ":", &saveptr);
            }
            free(path);
        }
    }
    if (runpath && runpath[0]) {
        char *path = strdup(runpath);
        if (path) {
            char *saveptr, *dir = strtok_r(path, ":", &saveptr);
            while (dir && ntry < 99) {
                if (!strcmp(dir, "$ORIGIN")) snprintf(tmp, sizeof(tmp), "./%s", name);
                else snprintf(tmp, sizeof(tmp), "%s/%s", dir, name);
                attempts[ntry++] = strdup(tmp); dir = strtok_r(NULL, ":", &saveptr);
            }
            free(path);
        }
    }
    for (int i = 0; i < ntry; i++) {
        h = dlopen_with_deps(attempts[i], runpath);
        if (h) return h;
    }
    return NULL;
}

struct thread_args {
    int (*main_fn)(int, char**, char**);
    int argc; char **argv; char **envp;
    void *tls, *base;
    void *init_array; size_t init_arraysz;
    Elf64_Addr init_off, fini_off, fini_array_off; size_t fini_arraysz;
};

static int thread_main(void *arg) {
    struct thread_args *ta = arg;
    if (ta->tls) set_tls(ta->tls);
    if (ta->init_off) ((void(*)(void))((char*)ta->base + ta->init_off))();
    if (ta->init_array && ta->init_arraysz) {
        Elf64_Addr *a = ta->init_array;
        int n = ta->init_arraysz / sizeof(Elf64_Addr);
        for (int i = 0; i < n; i++)
            if (a[i] && a[i] != (Elf64_Addr)-1) ((void(*)(void))a[i])();
    }
    int ret = ta->main_fn(ta->argc, ta->argv, ta->envp);
    void (*cxa)(void*) = find_sym("__cxa_finalize");
    if (cxa) cxa(NULL);
    if (ta->fini_array_off && ta->fini_arraysz) {
        Elf64_Addr *a = (Elf64_Addr*)((char*)ta->base + ta->fini_array_off);
        int n = ta->fini_arraysz / sizeof(Elf64_Addr);
        for (int i = n-1; i >= 0; i--)
            if (a[i] && a[i] != (Elf64_Addr)-1) ((void(*)(void))a[i])();
    }
    if (ta->fini_off) ((void(*)(void))((char*)ta->base + ta->fini_off))();
    return ret;
}

int memexec(const void *elf_data, size_t elf_size, int argc, char **argv) {
    if (!elf_data || elf_size < sizeof(Elf64_Ehdr)) return -1;
    const Elf64_Ehdr *ehdr = elf_data;
    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG)) return -1;

    const Elf64_Phdr *ph = (const Elf64_Phdr*)((const char*)elf_data + ehdr->e_phoff);
    Elf64_Addr max_vaddr = 0;
    const Elf64_Phdr *ph_dyn = NULL;
    seg_t segs[20]; int seg_n = 0;
    for (int i = 0; i < ehdr->e_phnum && seg_n < 20; i++) {
        if (ph[i].p_type == PT_LOAD) {
            Elf64_Addr end = ph[i].p_vaddr + ph[i].p_memsz;
            if (end > max_vaddr) max_vaddr = end;
            segs[seg_n++] = (seg_t){ph[i].p_vaddr, ph[i].p_memsz, (ph[i].p_flags & PF_W) != 0};
        }
        if (ph[i].p_type == PT_DYNAMIC) ph_dyn = &ph[i];
    }
    void *base = mmap(NULL, max_vaddr, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (base == MAP_FAILED) return -1;
    for (int i = 0; i < ehdr->e_phnum; i++)
        if (ph[i].p_type == PT_LOAD) {
            void *dst = (char*)base + ph[i].p_vaddr;
            memcpy(dst, (const char*)elf_data + ph[i].p_offset, ph[i].p_filesz);
            if (ph[i].p_memsz > ph[i].p_filesz)
                memset((char*)dst + ph[i].p_filesz, 0, ph[i].p_memsz - ph[i].p_filesz);
        }
    parse_tls(elf_data, elf_size, base);

    if (!ph_dyn) {
        char *fake[] = {"./prog", NULL}; int my_argc = argc; char **my_argv = argv;
        if (!my_argv) { my_argv = fake; my_argc = 1; }
        int ret = ((int(*)(int,char**))((char*)base + ehdr->e_entry))(my_argc, my_argv);
        munmap(base, max_vaddr); return ret;
    }

    Elf64_Dyn *dyn = (Elf64_Dyn*)((char*)base + ph_dyn->p_vaddr);
    Elf64_Rela *rela = NULL, *jmprel = NULL;
    size_t rela_sz = 0, jmprel_sz = 0;
    Elf64_Sym *symtab = NULL;
    const char *strtab = NULL;
    size_t strsz = 0;
    Elf64_Xword runpath_off = 0; int has_runpath = 0;
    Elf64_Addr init_off=0, fini_off=0, init_array_off=0, fini_array_off=0;
    size_t init_arraysz=0, fini_arraysz=0;
    int needed[50], needed_n=0;

    for (int i = 0; dyn[i].d_tag != DT_NULL; i++) {
        switch (dyn[i].d_tag) {
            case DT_RELA: rela = (Elf64_Rela*)((char*)base + dyn[i].d_un.d_ptr); break;
            case DT_RELASZ: rela_sz = dyn[i].d_un.d_val; break;
            case DT_SYMTAB: symtab = (Elf64_Sym*)((char*)base + dyn[i].d_un.d_ptr); break;
            case DT_STRTAB: strtab = (const char*)((char*)base + dyn[i].d_un.d_ptr); break;
            case DT_STRSZ: strsz = dyn[i].d_un.d_val; break;
            case DT_JMPREL: jmprel = (Elf64_Rela*)((char*)base + dyn[i].d_un.d_ptr); break;
            case DT_PLTRELSZ: jmprel_sz = dyn[i].d_un.d_val; break;
            case DT_INIT: init_off = dyn[i].d_un.d_ptr; break;
            case DT_FINI: fini_off = dyn[i].d_un.d_ptr; break;
            case DT_INIT_ARRAY: init_array_off = dyn[i].d_un.d_ptr; break;
            case DT_INIT_ARRAYSZ: init_arraysz = dyn[i].d_un.d_val; break;
            case DT_FINI_ARRAY: fini_array_off = dyn[i].d_un.d_ptr; break;
            case DT_FINI_ARRAYSZ: fini_arraysz = dyn[i].d_un.d_val; break;
            case DT_RUNPATH: case DT_RPATH:
                runpath_off = dyn[i].d_un.d_val; has_runpath = 1; break;
            case DT_NEEDED:
                if (needed_n < 50) needed[needed_n++] = dyn[i].d_un.d_val; break;
        }
    }
    const char *runpath = (has_runpath && strtab) ? strtab + runpath_off : NULL;
    if (strtab && needed_n) {
        for (int i = 0; i < needed_n; i++) {
            const char *lib = strtab + needed[i];
            smart_dlopen(lib, runpath);
        }
    }

    size_t tls_offset = has_tls ? TLS_TCB_SIZE : 0;
    if (rela && rela_sz && symtab && strtab) {
        int n = rela_sz / sizeof(Elf64_Rela);
        for (int i = 0; i < n; i++) {
            int type = ELF64_R_TYPE(rela[i].r_info), sym = ELF64_R_SYM(rela[i].r_info);
            Elf64_Addr *p = (Elf64_Addr*)((char*)base + rela[i].r_offset);
            switch (type) {
                case 0: break;
                case R_AARCH64_RELATIVE:
                    *p = (Elf64_Addr)base + rela[i].r_addend; break;
                case R_AARCH64_GLOB_DAT:
                case R_AARCH64_JUMP_SLOT:
                    *p = (symtab[sym].st_shndx && symtab[sym].st_value)
                         ? (Elf64_Addr)base + symtab[sym].st_value
                         : (Elf64_Addr)(uintptr_t)find_sym(strtab + symtab[sym].st_name);
                    break;
                case R_AARCH64_ABS64:
                    *p = (Elf64_Addr)base + symtab[sym].st_value + rela[i].r_addend; break;
                case R_AARCH64_TLS_TPREL:
                    *p = tls_offset + symtab[sym].st_value + rela[i].r_addend; break;
                case R_AARCH64_TLSDESC:
                    *p = (Elf64_Addr)base + symtab[sym].st_value + rela[i].r_addend; break;
            }
        }
    }
    if (jmprel && jmprel_sz && symtab && strtab) {
        int n = jmprel_sz / sizeof(Elf64_Rela);
        for (int i = 0; i < n; i++) {
            if (ELF64_R_TYPE(jmprel[i].r_info) != R_AARCH64_JUMP_SLOT) continue;
            int sym = ELF64_R_SYM(jmprel[i].r_info);
            Elf64_Addr *p = (Elf64_Addr*)((char*)base + jmprel[i].r_offset);
            const char *name = strtab + symtab[sym].st_name;
            void *addr = (symtab[sym].st_shndx && symtab[sym].st_value)
                         ? (char*)base + symtab[sym].st_value : find_sym(name);
            *p = (Elf64_Addr)(uintptr_t)addr;
        }
    }
    for (int i = 0; i < seg_n; i++) {
        void *pg = (void*)((uintptr_t)((char*)base + segs[i].vaddr) & ~0xFFF);
        size_t sz = ((uintptr_t)((char*)base + segs[i].vaddr + segs[i].memsz) - (uintptr_t)pg + 0xFFF) & ~0xFFF;
        mprotect(pg, sz, PROT_READ | (segs[i].writeable ? PROT_WRITE : PROT_EXEC));
    }

    int (*main_fn)(int, char**, char**) = NULL;
    if (symtab && strtab && strsz) {
        for (size_t i = 0; ; i++) {
            if (symtab[i].st_name == 0 && i > 50) break;
            const char *nm = strtab + symtab[i].st_name;
            if (nm < strtab || nm >= strtab + strsz) break;
            if (!strcmp(nm, "main") && symtab[i].st_value) {
                main_fn = (int(*)(int,char**,char**))((char*)base + symtab[i].st_value);
                break;
            }
        }
    }

    int ret = 0;
    char *fake[] = {"./prog", NULL}; int my_argc = argc; char **my_argv = argv;
    if (!my_argv) { my_argv = fake; my_argc = 1; }
    extern char **environ;

    if (main_fn) {
        if (has_tls) {
            void *tls = allocate_tls();
            struct thread_args ta = { main_fn, my_argc, my_argv, environ, tls, base,
                (void*)(init_array_off ? (char*)base + init_array_off : NULL), init_arraysz,
                init_off, fini_off, fini_array_off, fini_arraysz };
            int stack_size = 1024*1024;
            void *child = mmap(NULL, stack_size, PROT_READ|PROT_WRITE,
                               MAP_PRIVATE|MAP_ANONYMOUS|MAP_STACK, -1, 0);
            if (!child) return -1;
            int tid = clone(thread_main, (char*)child + stack_size,
                            CLONE_VM|CLONE_FILES|CLONE_SIGHAND|CLONE_THREAD|CLONE_SETTLS,
                            &ta, 0, tls);
            if (tid < 0) { munmap(child, stack_size); return -1; }
            struct timespec ts = {10, 0};
            while (syscall(__NR_futex, &tid, FUTEX_WAIT, tid, &ts) != 0 && errno == EAGAIN) {}
            munmap(child, stack_size); munmap(tls, tls_total_size + TLS_TCB_SIZE);
        } else {
            if (init_off) ((void(*)(void))((char*)base + init_off))();
            if (init_array_off && init_arraysz) {
                Elf64_Addr *a = (Elf64_Addr*)((char*)base + init_array_off);
                int n = init_arraysz / sizeof(Elf64_Addr);
                for (int i = 0; i < n; i++)
                    if (a[i] && a[i] != (Elf64_Addr)-1) ((void(*)(void))a[i])();
            }
            ret = main_fn(my_argc, my_argv, environ);
            void (*cxa)(void*) = find_sym("__cxa_finalize");
            if (cxa) cxa(NULL);
            if (fini_array_off && fini_arraysz) {
                Elf64_Addr *a = (Elf64_Addr*)((char*)base + fini_array_off);
                int n = fini_arraysz / sizeof(Elf64_Addr);
                for (int i = n-1; i >= 0; i--)
                    if (a[i] && a[i] != (Elf64_Addr)-1) ((void(*)(void))a[i])();
            }
            if (fini_off) ((void(*)(void))((char*)base + fini_off))();
        }
    } else {
        typedef void (*entry_t)(int, char**, char**, void*);
        entry_t entry = (entry_t)((char*)base + ehdr->e_entry);
        long auxv[38] = {0};
        auxv[0] = AT_PHDR; auxv[1] = (Elf64_Addr)elf_data + ehdr->e_phoff;
        auxv[2] = AT_PHENT; auxv[3] = ehdr->e_phentsize;
        auxv[4] = AT_PHNUM; auxv[5] = ehdr->e_phnum;
        auxv[6] = AT_ENTRY; auxv[7] = ehdr->e_entry;
        auxv[8] = AT_BASE;  auxv[9] = 0;
        auxv[10] = AT_NULL;
        entry(my_argc, my_argv, environ, auxv);
    }

    munmap(base, max_vaddr);
    return ret;
}
