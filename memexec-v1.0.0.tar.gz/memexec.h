#ifndef MEMEXEC_H
#define MEMEXEC_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int memexec(const void *elf_data, size_t elf_size, int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif
